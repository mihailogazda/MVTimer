MVTimer
=======

Elders Scrolls Online Addon timer made with love for my wife.

###Settings
Press Esc to open menu, go to controls and update MVTimer Settings properties.
